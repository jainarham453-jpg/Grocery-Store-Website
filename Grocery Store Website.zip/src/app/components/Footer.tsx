import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, ShoppingCart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="bg-green-600 text-white p-2 rounded-lg">
                <ShoppingCart className="w-6 h-6" />
              </div>
              <span>FreshMart</span>
            </div>
            <p className="text-gray-400 text-sm">
              Your trusted online grocery store delivering fresh products to your doorstep.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/" className="text-gray-400 hover:text-white transition">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/products" className="text-gray-400 hover:text-white transition">
                  Products
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-400 hover:text-white transition">
                  Contact
                </Link>
              </li>
              <li>
                <Link to="/cart" className="text-gray-400 hover:text-white transition">
                  Cart
                </Link>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="mb-4">Categories</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/products/fruits" className="text-gray-400 hover:text-white transition">
                  Fruits
                </Link>
              </li>
              <li>
                <Link to="/products/vegetables" className="text-gray-400 hover:text-white transition">
                  Vegetables
                </Link>
              </li>
              <li>
                <Link to="/products/dairy" className="text-gray-400 hover:text-white transition">
                  Dairy
                </Link>
              </li>
              <li>
                <Link to="/products/snacks" className="text-gray-400 hover:text-white transition">
                  Snacks
                </Link>
              </li>
              <li>
                <Link to="/products/beverages" className="text-gray-400 hover:text-white transition">
                  Beverages
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="mb-4">Contact Us</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <span className="text-gray-400">
                  Mahaveer Rose, Bengaluru
                </span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-green-600" />
                <a href="tel:8272875310" className="text-gray-400 hover:text-white transition">
                  8272875310
                </a>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-green-600" />
                <a href="mailto:jainarham453@gmail.com" className="text-gray-400 hover:text-white transition">
                  jainarham453@gmail.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
          <p>&copy; {new Date().getFullYear()} FreshMart. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
