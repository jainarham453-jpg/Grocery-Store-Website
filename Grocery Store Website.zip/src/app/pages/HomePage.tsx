import { Link } from 'react-router-dom';
import { ArrowRight, ShoppingBag, Truck, Shield, Clock } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import SeedData from '../components/SeedData';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

const categories = [
  {
    name: 'Fruits',
    image: 'https://images.unsplash.com/photo-1556011284-54aa6466d402?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGZydWl0cyUyMG1hcmtldHxlbnwxfHx8fDE3NjU2NDg3MzF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    link: '/products/fruits'
  },
  {
    name: 'Vegetables',
    image: 'https://images.unsplash.com/photo-1714224247661-ee250f55a842?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHZlZ2V0YWJsZXMlMjBncm9jZXJpZXN8ZW58MXx8fHwxNzY1NjQ4NzMxfDA&ixlib=rb-4.1.0&q=80&w=1080',
    link: '/products/vegetables'
  },
  {
    name: 'Dairy',
    image: 'https://images.unsplash.com/photo-1635714293982-65445548ac42?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYWlyeSUyMG1pbGslMjBwcm9kdWN0c3xlbnwxfHx8fDE3NjU2NDY0MDB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    link: '/products/dairy'
  },
  {
    name: 'Snacks',
    image: 'https://images.unsplash.com/photo-1569420067112-b57b4f024595?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGh5JTIwc25hY2tzfGVufDF8fHx8MTc2NTU3MTQ2MXww&ixlib=rb-4.1.0&q=80&w=1080',
    link: '/products/snacks'
  },
  {
    name: 'Beverages',
    image: 'https://images.unsplash.com/photo-1652922664558-03d0f2932e58?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZXZlcmFnZXMlMjBkcmlua3N8ZW58MXx8fHwxNzY1NjQ4NzMyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    link: '/products/beverages'
  }
];

const features = [
  {
    icon: Truck,
    title: 'Free Delivery',
    description: 'On orders above ₹500'
  },
  {
    icon: Clock,
    title: 'Quick Service',
    description: 'Delivery within 2 hours'
  },
  {
    icon: Shield,
    title: 'Secure Payment',
    description: '100% secure transactions'
  },
  {
    icon: ShoppingBag,
    title: 'Fresh Products',
    description: 'Always fresh & quality'
  }
];

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-green-600 to-green-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-white mb-6">
                Fresh Groceries Delivered to Your Doorstep
              </h1>
              <p className="text-green-50 text-lg mb-8">
                Shop from our wide range of fresh fruits, vegetables, dairy products, and more. 
                Quality guaranteed with fast delivery in Bengaluru.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/products"
                  className="bg-white text-green-600 px-8 py-3 rounded-lg hover:bg-gray-100 transition inline-flex items-center justify-center space-x-2"
                >
                  <span>Shop Now</span>
                  <ArrowRight className="w-5 h-5" />
                </Link>
                <Link
                  to="/contact"
                  className="border-2 border-white text-white px-8 py-3 rounded-lg hover:bg-white hover:text-green-600 transition inline-flex items-center justify-center"
                >
                  Contact Us
                </Link>
              </div>
              
              {/* Location */}
              <div className="mt-8 bg-white/10 backdrop-blur-sm rounded-lg p-4 inline-block">
                <p className="text-green-50 text-sm">Serving Mahaveer Rose, Bengaluru</p>
              </div>
            </div>
            
            <div className="hidden md:block">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1483619373149-740b4ce76d2e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncm9jZXJ5JTIwc2hvcHBpbmclMjBjYXJ0fGVufDF8fHx8MTc2NTU4NTc2MXww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Fresh Groceries"
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                  <feature.icon className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600 text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-gray-900 mb-4">Shop by Category</h2>
            <p className="text-gray-600">
              Browse through our wide range of fresh products
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {categories.map((category, index) => (
              <Link
                key={index}
                to={category.link}
                className="group"
              >
                <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
                  <div className="h-40 overflow-hidden">
                    <ImageWithFallback
                      src={category.image}
                      alt={category.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition duration-300"
                    />
                  </div>
                  <div className="p-4 text-center">
                    <h3 className="text-gray-900">{category.name}</h3>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-green-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-white mb-4">Ready to Start Shopping?</h2>
          <p className="text-green-50 text-lg mb-8 max-w-2xl mx-auto">
            Join thousands of happy customers enjoying fresh groceries delivered right to their homes
          </p>
          <Link
            to="/products"
            className="inline-flex items-center space-x-2 bg-white text-green-600 px-8 py-4 rounded-lg hover:bg-gray-100 transition"
          >
            <ShoppingBag className="w-5 h-5" />
            <span>Browse Products</span>
          </Link>
        </div>
      </section>

      <Footer />
      
      {/* Seed Data Component for quick setup */}
      <SeedData />
    </div>
  );
}