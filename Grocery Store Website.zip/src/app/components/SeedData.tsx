import { useState } from 'react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

export default function SeedData() {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const seedDatabase = async () => {
    setLoading(true);
    setMessage('Seeding database...');

    try {
      const url = `https://${projectId}.supabase.co/functions/v1/make-server-3d698934/seed`;
      console.log('Seeding database at:', url);
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        }
      });

      console.log('Seed response status:', response.status);
      
      if (response.ok) {
        const data = await response.json();
        console.log('Seed response:', data);
        setMessage('✅ Database seeded successfully with 18 sample products!');
      } else {
        const errorText = await response.text();
        console.error('Seed error response:', errorText);
        setMessage(`❌ Failed to seed database: ${response.status} ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error seeding database:', error);
      setMessage(`❌ Network error: ${error instanceof Error ? error.message : 'Unknown error'}. Check console for details.`);
    } finally {
      setLoading(false);
    }
  };

  const createAdminUser = async () => {
    setLoading(true);
    setMessage('Creating admin user...');

    try {
      const url = `https://${projectId}.supabase.co/functions/v1/make-server-3d698934/signup`;
      console.log('Creating admin at:', url);
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          email: 'admin@freshmart.com',
          password: 'admin123',
          name: 'Admin User',
          isAdmin: true
        })
      });

      console.log('Admin creation response status:', response.status);

      if (response.ok) {
        const data = await response.json();
        console.log('Admin creation response:', data);
        setMessage('✅ Admin user created! Email: admin@freshmart.com | Password: admin123');
      } else {
        const data = await response.json();
        
        // Check if user already exists - this is actually OK!
        if (data.error && (data.error.includes('already') || data.error.includes('registered'))) {
          console.log('Admin user already exists (this is OK):', data);
          setMessage('✅ Admin user already exists! Email: admin@freshmart.com | Password: admin123');
        } else {
          console.error('Admin creation error:', data);
          setMessage(`⚠️ ${data.error || 'Failed to create admin'}`);
        }
      }
    } catch (error) {
      console.error('Error creating admin:', error);
      setMessage(`❌ Network error: ${error instanceof Error ? error.message : 'Unknown error'}. Check console for details.`);
    } finally {
      setLoading(false);
    }
  };

  const testBackend = async () => {
    setLoading(true);
    setMessage('Testing backend connection...');

    try {
      const url = `https://${projectId}.supabase.co/functions/v1/make-server-3d698934/health`;
      console.log('Testing backend at:', url);
      
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });

      console.log('Health check response status:', response.status);

      if (response.ok) {
        const data = await response.json();
        console.log('Health check response:', data);
        setMessage(`✅ Backend is running! Status: ${data.status}`);
      } else {
        setMessage(`❌ Backend not responding: ${response.status} ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error testing backend:', error);
      setMessage(`❌ Backend connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 bg-white rounded-lg shadow-xl p-6 max-w-md z-50 border-2 border-purple-600">
      <h3 className="text-gray-900 mb-4">🚀 Quick Setup</h3>
      
      <div className="space-y-3 mb-4">
        <button
          onClick={testBackend}
          disabled={loading}
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-400 text-sm"
        >
          {loading ? 'Testing...' : '🔍 Test Backend'}
        </button>

        <button
          onClick={seedDatabase}
          disabled={loading}
          className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition disabled:bg-gray-400"
        >
          {loading ? 'Loading...' : '📦 Load Sample Products'}
        </button>

        <button
          onClick={createAdminUser}
          disabled={loading}
          className="w-full bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition disabled:bg-gray-400"
        >
          {loading ? 'Loading...' : '👤 Create Admin User'}
        </button>
      </div>

      {message && (
        <div className={`p-3 rounded-lg text-sm ${
          message.includes('✅') ? 'bg-green-50 text-green-700' : 
          message.includes('⚠️') ? 'bg-yellow-50 text-yellow-700' :
          'bg-red-50 text-red-700'
        }`}>
          {message}
        </div>
      )}

      <div className="mt-4 pt-4 border-t text-xs text-gray-500">
        <p className="mb-2">📝 Setup steps:</p>
        <ul className="space-y-1 ml-4 list-disc">
          <li>1. Test backend connection first</li>
          <li>2. Load sample products</li>
          <li>3. Create admin user</li>
          <li>4. Login at /admin/login</li>
        </ul>
      </div>
    </div>
  );
}