import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { CheckCircle, Package, MapPin, CreditCard } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { useAuth } from '../context/AuthContext';

interface Order {
  id: string;
  items: any[];
  totalAmount: number;
  paymentMethod: string;
  shippingInfo: any;
  status: string;
  createdAt: string;
}

export default function OrderConfirmationPage() {
  const { orderId } = useParams();
  const { supabase } = useAuth();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOrder();
  }, [orderId]);

  const fetchOrder = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-3d698934/orders/${orderId}`,
        {
          headers: {
            'Authorization': `Bearer ${session?.access_token || publicAnonKey}`
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        setOrder(data.order);
      }
    } catch (error) {
      console.error('Error fetching order:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading order details...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h2 className="text-gray-900 mb-4">Order Not Found</h2>
            <Link to="/" className="text-green-600 hover:text-green-700">
              Return to Home
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Success Message */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-4">
            <CheckCircle className="w-12 h-12 text-green-600" />
          </div>
          <h1 className="text-gray-900 mb-2">Order Confirmed!</h1>
          <p className="text-gray-600">Thank you for your order. We'll deliver it soon.</p>
          <p className="text-gray-500 text-sm mt-2">Order ID: {order.id}</p>
        </div>

        {/* Order Details */}
        <div className="bg-white rounded-lg shadow-md p-8 mb-6">
          <div className="flex items-center space-x-3 mb-6">
            <Package className="w-6 h-6 text-green-600" />
            <h2 className="text-gray-900">Order Details</h2>
          </div>

          <div className="space-y-4 mb-6">
            {order.items.map((item: any, index: number) => (
              <div key={index} className="flex justify-between items-center py-3 border-b">
                <div>
                  <p className="text-gray-900">{item.name}</p>
                  <p className="text-sm text-gray-500">Quantity: {item.quantity}</p>
                </div>
                <p className="text-gray-900">₹{(item.price * item.quantity).toFixed(2)}</p>
              </div>
            ))}
          </div>

          <div className="border-t pt-4">
            <div className="flex justify-between text-gray-900">
              <span>Total Amount</span>
              <span>₹{order.totalAmount.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Shipping Info */}
        <div className="bg-white rounded-lg shadow-md p-8 mb-6">
          <div className="flex items-center space-x-3 mb-6">
            <MapPin className="w-6 h-6 text-green-600" />
            <h2 className="text-gray-900">Delivery Address</h2>
          </div>

          <div className="text-gray-600">
            <p className="mb-1">{order.shippingInfo.fullName}</p>
            <p className="mb-1">{order.shippingInfo.address}</p>
            <p className="mb-1">{order.shippingInfo.city}, {order.shippingInfo.pincode}</p>
            <p>Phone: {order.shippingInfo.phone}</p>
          </div>
        </div>

        {/* Payment Method */}
        <div className="bg-white rounded-lg shadow-md p-8 mb-6">
          <div className="flex items-center space-x-3 mb-6">
            <CreditCard className="w-6 h-6 text-green-600" />
            <h2 className="text-gray-900">Payment Method</h2>
          </div>

          <p className="text-gray-600">
            {order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Online Payment (Paid)'}
          </p>
        </div>

        {/* Expected Delivery */}
        <div className="bg-green-50 rounded-lg p-6 mb-6">
          <h3 className="text-green-900 mb-2">Expected Delivery</h3>
          <p className="text-green-700">
            Your order will be delivered within 2-3 hours
          </p>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4">
          <Link
            to="/products"
            className="flex-1 bg-green-600 text-white text-center py-3 rounded-lg hover:bg-green-700 transition"
          >
            Continue Shopping
          </Link>
          <Link
            to="/"
            className="flex-1 bg-white text-green-600 text-center py-3 rounded-lg border-2 border-green-600 hover:bg-green-50 transition"
          >
            Back to Home
          </Link>
        </div>
      </div>

      <Footer />
    </div>
  );
}
