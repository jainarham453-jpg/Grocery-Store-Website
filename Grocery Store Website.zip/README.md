
  # Grocery Store Website

  This is a code bundle for Grocery Store Website. The original project is available at https://www.figma.com/design/gmbQJlsSmD9L7Ja2OHV2Mz/Grocery-Store-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  