# 🛒 FreshMart - Complete Grocery Store Website

## 🎉 Welcome!

This is a **fully functional, production-ready** grocery store website with:
- ✅ User Authentication (Login/Register)
- ✅ Product Catalog with Categories
- ✅ Shopping Cart System
- ✅ Checkout & Order Management
- ✅ Admin Dashboard (Product & Order Management)
- ✅ Contact Form with Google Maps
- ✅ Test Payment Gateway Integration
- ✅ Responsive Design (Mobile, Tablet, Desktop)
- ✅ Supabase Backend (Database, Auth, API)

---

## 🚀 QUICK START (3 Steps)

### Step 1: Load Sample Products
1. Visit the homepage
2. Look for the **purple "Quick Setup" panel** in the bottom-right corner
3. Click **"📦 Load Sample Products"** button
4. Wait for success message

### Step 2: Create Admin Account
1. In the same Quick Setup panel
2. Click **"👤 Create Admin User"** button
3. Note the credentials:
   - **Email:** admin@freshmart.com
   - **Password:** admin123

### Step 3: Start Shopping!
- Browse products on the homepage
- Add items to cart
- Register as a regular user
- Place orders

---

## 📋 FEATURES OVERVIEW

### 🏠 **HOME PAGE**
- Modern hero banner with call-to-action
- Category cards (Fruits, Vegetables, Dairy, Snacks, Beverages)
- Feature highlights (Free Delivery, Quick Service, Secure Payment)
- Location display: Mahaveer Rose, Bengaluru

### 🛍️ **PRODUCTS PAGE**
- Complete product catalog with images
- Category filtering (All, Fruits, Vegetables, etc.)
- Real-time search functionality
- Add to cart with quantity controls
- Price per unit display

### 🛒 **SHOPPING CART**
- View all cart items
- Update quantities (increase/decrease)
- Remove items
- Automatic price calculation
- Delivery fee logic (Free above ₹500)
- Persistent cart (saved in browser)

### 💳 **CHECKOUT PAGE** (Requires Login)
- Shipping information form
- Payment method selection:
  - Online Payment (Test Mode - Razorpay/Stripe simulation)
  - Cash on Delivery (COD)
- Order summary with item breakdown
- Real-time total calculation

### ✅ **ORDER CONFIRMATION**
- Order details with unique Order ID
- Item list and pricing
- Delivery address confirmation
- Payment method display
- Expected delivery time (2-3 hours)

### 🔐 **USER AUTHENTICATION**
- **User Registration:**
  - Email & Password
  - Full name
  - Automatic email confirmation
- **User Login:**
  - Secure authentication
  - Session management
  - Protected routes

### 👨‍💼 **ADMIN DASHBOARD** (Admin Only)
Located at `/admin/dashboard` - Requires admin login

**Admin Login Credentials:**
- Email: admin@freshmart.com
- Password: admin123

**Dashboard Features:**
1. **Statistics Overview:**
   - Total Products
   - Total Orders
   - Total Revenue
   - Pending Orders

2. **Product Management:**
   - View all products
   - Add new products (Name, Price, Image URL, Category, Unit)
   - Edit existing products
   - Delete products
   - Real-time updates

3. **Order Management:**
   - View all customer orders
   - Order details (items, customer info, address)
   - Update order status:
     - Pending
     - Processing
     - Delivered
     - Cancelled
   - Filter by status

4. **Customer Messages:**
   - View contact form submissions
   - Customer name, email, message
   - Timestamp for each message

### 📞 **CONTACT PAGE**
- Contact form (Name, Email, Message)
- Messages saved to database
- Success confirmation
- Contact information display:
  - **Address:** Mahaveer Rose, Bengaluru
  - **Phone:** 8272875310
  - **Email:** jainarham453@gmail.com
- Google Maps integration
- Store hours display

---

## 🔧 TECHNICAL STACK

### **Frontend:**
- React 18.2
- TypeScript
- Tailwind CSS v4.0
- React Router DOM (SPA routing)
- Lucide React (Icons)

### **Backend:**
- Supabase (Database + Auth + Edge Functions)
- Hono (Web server framework)
- REST API architecture
- Key-Value store for data persistence

### **Authentication:**
- Supabase Auth
- Email/Password authentication
- Role-based access control (User/Admin)
- Protected routes
- Session management

### **Database Schema:**
- **Products:** id, name, price, image, category, unit
- **Orders:** id, userId, items, shippingInfo, paymentMethod, totalAmount, status, createdAt
- **Messages:** id, name, email, message, createdAt
- **Users:** Managed by Supabase Auth with metadata (name, isAdmin)

---

## 👥 USER ROLES

### **Regular User:**
- Browse products
- Add to cart
- Place orders
- View order confirmation
- Contact form submission

### **Admin User:**
- All regular user features
- Access admin dashboard
- Manage products (CRUD operations)
- Manage orders (view, update status)
- View customer messages

---

## 📱 RESPONSIVE DESIGN

✅ **Mobile** (320px - 767px)
- Hamburger menu
- Single column layouts
- Touch-optimized buttons
- Mobile-friendly cart

✅ **Tablet** (768px - 1023px)
- 2-column product grid
- Collapsible navigation
- Optimized spacing

✅ **Desktop** (1024px+)
- Full navigation bar
- 4-column product grid
- Sidebar layouts
- Enhanced hover effects

---

## 💰 PAYMENT INTEGRATION

### **Test Mode Payment Gateway**
The application includes a **simulated payment gateway** for demonstration:

**Online Payment:**
- Simulates Razorpay/Stripe integration
- 2-second processing delay for realism
- No real transactions occur
- Test mode clearly indicated

**Cash on Delivery:**
- Traditional COD option
- No payment processing required
- Order confirmation immediate

**For Production:**
To integrate real payment gateways:
1. Sign up for Razorpay or Stripe
2. Add API keys to environment variables
3. Update checkout flow in `/pages/CheckoutPage.tsx`
4. Implement webhook handlers in backend

---

## 🗺️ LOCATION & MAP

**Store Location:**
- Mahaveer Rose, Bengaluru, Karnataka

**Google Maps:**
- Embedded interactive map on contact page
- Shows Bengaluru area
- Users can zoom and navigate

---

## 🔒 SECURITY FEATURES

✅ **Authentication:**
- Secure password hashing (handled by Supabase)
- JWT tokens for session management
- HTTP-only cookies

✅ **Authorization:**
- Route protection (checkout, admin)
- Role-based access control
- API endpoint protection

✅ **Data Validation:**
- Client-side form validation
- Server-side validation
- SQL injection protection (KV store)

---

## 📊 DATABASE OPERATIONS

All data is stored in Supabase's key-value store:

**Products:**
- Key format: `product:{productId}`
- Searchable by prefix
- CRUD operations via admin panel

**Orders:**
- Key format: `order:{orderId}` and `userOrder:{userId}:{orderId}`
- Dual indexing for user queries and admin queries
- Status updates tracked

**Messages:**
- Key format: `message:{messageId}`
- Timestamped entries
- Admin-only access

---

## 🎨 DESIGN SYSTEM

**Colors:**
- Primary: Green (#059669 - green-600)
- Secondary: Purple (#9333EA - purple-600)
- Success: Green shades
- Error: Red shades
- Gray scale for text and backgrounds

**Typography:**
- System fonts optimized for readability
- Responsive font sizes
- Clear hierarchy

**Components:**
- Consistent button styles
- Form inputs with focus states
- Card-based layouts
- Shadow and hover effects

---

## 📝 API ENDPOINTS

### **Public Endpoints:**
- `GET /products` - Get all products
- `POST /contact` - Submit contact message
- `POST /signup` - User registration
- `POST /seed` - Initialize sample data

### **Protected Endpoints (Requires Auth):**
- `POST /orders` - Create new order
- `GET /orders/:id` - Get specific order

### **Admin Endpoints (Requires Admin Auth):**
- `POST /admin/products` - Add product
- `PUT /admin/products/:id` - Update product
- `DELETE /admin/products/:id` - Delete product
- `GET /admin/orders` - Get all orders
- `PATCH /admin/orders/:id` - Update order status
- `GET /admin/messages` - Get all messages

---

## 🐛 TROUBLESHOOTING

### **Products not showing:**
- Click "Load Sample Products" in Quick Setup panel
- Refresh the page
- Check browser console for errors

### **Can't login:**
- Verify email/password
- Check if user is registered
- Clear browser cache and cookies

### **Admin dashboard not accessible:**
- Use admin credentials (admin@freshmart.com / admin123)
- Login via `/admin/login` NOT `/login`
- Check if admin user was created

### **Cart not persisting:**
- Enable localStorage in browser
- Clear cache if cart shows old data

### **Orders not saving:**
- Ensure you're logged in
- Check network connectivity
- View browser console for API errors

---

## 🌐 DEPLOYMENT READY

This application is ready to deploy on:
- **Vercel** (Recommended for React apps)
- **Netlify**
- **Render**
- **Supabase Hosting**

**Environment Variables Needed:**
- `SUPABASE_URL` (Auto-configured in Figma Make)
- `SUPABASE_ANON_KEY` (Auto-configured in Figma Make)
- `SUPABASE_SERVICE_ROLE_KEY` (Auto-configured in Figma Make)

---

## 📞 SUPPORT & CONTACT

**Store Contact:**
- Phone: 8272875310
- Email: jainarham453@gmail.com
- Location: Mahaveer Rose, Bengaluru

**Store Hours:**
- Monday - Saturday: 8:00 AM - 10:00 PM
- Sunday: 9:00 AM - 9:00 PM

---

## ✨ ADDITIONAL FEATURES

### **Cart Features:**
- Persistent cart across sessions
- Quantity increment/decrement controls
- Real-time price updates
- Free delivery threshold indicator
- Continue shopping option

### **Order Features:**
- Unique order ID for tracking
- Order history (user-specific)
- Status tracking
- Delivery time estimates

### **Admin Features:**
- Comprehensive dashboard
- Statistics at a glance
- Quick product management
- Order status workflow
- Customer message inbox

---

## 🎯 DEMO WORKFLOW

### **As a Customer:**
1. Visit homepage → Browse products
2. Click product category → Filter products
3. Add items to cart → View cart
4. Register/Login → Proceed to checkout
5. Enter shipping info → Select payment
6. Place order → View confirmation

### **As an Admin:**
1. Go to `/admin/login`
2. Login with admin credentials
3. View dashboard statistics
4. Add/Edit/Delete products
5. Manage customer orders
6. Update order status
7. View customer messages

---

## 🔄 FUTURE ENHANCEMENTS (Optional)

- Product reviews and ratings
- Wishlist functionality
- Order tracking with live updates
- Email notifications (order confirmation, status updates)
- Discount codes and promotions
- Multiple delivery addresses
- Reorder previous orders
- Product recommendations
- Advanced search with filters
- Social login (Google, Facebook)

---

## 📄 LICENSE & USAGE

This is a demonstration project for portfolio/educational purposes.

**Important Notice:**
⚠️ Figma Make is designed for demonstration purposes and is not meant for collecting PII (Personally Identifiable Information) or securing sensitive production data. For a real production grocery store, you should:
- Deploy to your own infrastructure
- Implement additional security measures
- Use production-grade payment gateways
- Set up email verification
- Add GDPR compliance features
- Implement proper error logging

---

## 🙏 CREDITS

- **Icons:** Lucide React
- **Images:** Unsplash (via API)
- **Maps:** Google Maps Embed API
- **Backend:** Supabase
- **Hosting:** Figma Make Platform

---

## 📚 CODE STRUCTURE

```
/
├── App.tsx                  # Main app with routing
├── package.json             # Dependencies
├── SETUP_GUIDE.md          # This file
│
├── /components/
│   ├── Navbar.tsx          # Navigation bar
│   ├── Footer.tsx          # Footer component
│   ├── ProductCard.tsx     # Product display card
│   └── SeedData.tsx        # Database seeding tool
│
├── /pages/
│   ├── HomePage.tsx        # Landing page
│   ├── ProductsPage.tsx    # Product catalog
│   ├── CartPage.tsx        # Shopping cart
│   ├── CheckoutPage.tsx    # Checkout flow
│   ├── LoginPage.tsx       # User login
│   ├── RegisterPage.tsx    # User registration
│   ├── AdminLoginPage.tsx  # Admin login
│   ├── AdminDashboard.tsx  # Admin panel
│   ├── ContactPage.tsx     # Contact form
│   └── OrderConfirmationPage.tsx
│
├── /context/
│   ├── AuthContext.tsx     # Authentication state
│   └── CartContext.tsx     # Cart state management
│
└── /supabase/functions/server/
    ├── index.tsx           # API server (Hono)
    └── kv_store.tsx        # Database utilities
```

---

## 🎉 ENJOY YOUR GROCERY STORE!

Your complete, production-ready grocery store website is now live!

Start by clicking the **"Load Sample Products"** button on the homepage, then explore all the features.

Happy Shopping! 🛒✨
