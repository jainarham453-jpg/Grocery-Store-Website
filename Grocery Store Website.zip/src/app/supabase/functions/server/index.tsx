import { Hono } from 'npm:hono@4';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'jsr:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

// Middleware - CORS must allow all origins for development
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));
app.use('*', logger(console.log));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Helper function to generate unique ID
function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// Helper function to verify admin
async function verifyAdmin(accessToken: string): Promise<boolean> {
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  if (!user || error) return false;
  return user.user_metadata?.isAdmin === true;
}

// ==================== AUTHENTICATION ROUTES ====================

// User signup
app.post('/make-server-3d698934/signup', async (c) => {
  try {
    const { email, password, name, isAdmin = false } = await c.req.json();

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name, isAdmin },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      return c.json({ error: error.message }, 400);
    }

    return c.json({ success: true, user: data.user });
  } catch (error) {
    console.error('Signup error:', error);
    return c.json({ error: 'Signup failed' }, 500);
  }
});

// ==================== PRODUCT ROUTES ====================

// Get all products
app.get('/make-server-3d698934/products', async (c) => {
  try {
    const products = await kv.getByPrefix('product:');
    return c.json({ products: products || [] });
  } catch (error) {
    console.error('Error fetching products:', error);
    return c.json({ error: 'Failed to fetch products' }, 500);
  }
});

// Admin: Add product
app.post('/make-server-3d698934/admin/products', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken || !(await verifyAdmin(accessToken))) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { name, price, image, category, unit } = await c.req.json();
    const productId = generateId();
    
    const product = {
      id: productId,
      name,
      price,
      image,
      category,
      unit
    };

    await kv.set(`product:${productId}`, product);
    return c.json({ success: true, product });
  } catch (error) {
    console.error('Error adding product:', error);
    return c.json({ error: 'Failed to add product' }, 500);
  }
});

// Admin: Update product
app.put('/make-server-3d698934/admin/products/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken || !(await verifyAdmin(accessToken))) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const productId = c.req.param('id');
    const { name, price, image, category, unit } = await c.req.json();
    
    const product = {
      id: productId,
      name,
      price,
      image,
      category,
      unit
    };

    await kv.set(`product:${productId}`, product);
    return c.json({ success: true, product });
  } catch (error) {
    console.error('Error updating product:', error);
    return c.json({ error: 'Failed to update product' }, 500);
  }
});

// Admin: Delete product
app.delete('/make-server-3d698934/admin/products/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken || !(await verifyAdmin(accessToken))) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const productId = c.req.param('id');
    await kv.del(`product:${productId}`);
    return c.json({ success: true });
  } catch (error) {
    console.error('Error deleting product:', error);
    return c.json({ error: 'Failed to delete product' }, 500);
  }
});

// ==================== ORDER ROUTES ====================

// Create order
app.post('/make-server-3d698934/orders', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user || error) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { items, shippingInfo, paymentMethod, totalAmount } = await c.req.json();
    const orderId = generateId();
    
    const order = {
      id: orderId,
      userId: user.id,
      items,
      shippingInfo,
      paymentMethod,
      totalAmount,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    await kv.set(`order:${orderId}`, order);
    await kv.set(`userOrder:${user.id}:${orderId}`, order);
    
    return c.json({ success: true, orderId, order });
  } catch (error) {
    console.error('Error creating order:', error);
    return c.json({ error: 'Failed to create order' }, 500);
  }
});

// Get specific order
app.get('/make-server-3d698934/orders/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user || error) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const orderId = c.req.param('id');
    const order = await kv.get(`order:${orderId}`);
    
    if (!order) {
      return c.json({ error: 'Order not found' }, 404);
    }

    // Check if user owns this order or is admin
    if (order.userId !== user.id && !user.user_metadata?.isAdmin) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    return c.json({ order });
  } catch (error) {
    console.error('Error fetching order:', error);
    return c.json({ error: 'Failed to fetch order' }, 500);
  }
});

// Admin: Get all orders
app.get('/make-server-3d698934/admin/orders', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken || !(await verifyAdmin(accessToken))) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const orders = await kv.getByPrefix('order:');
    return c.json({ orders: orders || [] });
  } catch (error) {
    console.error('Error fetching orders:', error);
    return c.json({ error: 'Failed to fetch orders' }, 500);
  }
});

// Admin: Update order status
app.patch('/make-server-3d698934/admin/orders/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken || !(await verifyAdmin(accessToken))) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const orderId = c.req.param('id');
    const { status } = await c.req.json();
    
    const order = await kv.get(`order:${orderId}`);
    if (!order) {
      return c.json({ error: 'Order not found' }, 404);
    }

    const updatedOrder = { ...order, status };
    await kv.set(`order:${orderId}`, updatedOrder);
    await kv.set(`userOrder:${order.userId}:${orderId}`, updatedOrder);
    
    return c.json({ success: true, order: updatedOrder });
  } catch (error) {
    console.error('Error updating order:', error);
    return c.json({ error: 'Failed to update order' }, 500);
  }
});

// ==================== CONTACT ROUTES ====================

// Submit contact message
app.post('/make-server-3d698934/contact', async (c) => {
  try {
    const { name, email, message } = await c.req.json();
    const messageId = generateId();
    
    const contactMessage = {
      id: messageId,
      name,
      email,
      message,
      createdAt: new Date().toISOString()
    };

    await kv.set(`message:${messageId}`, contactMessage);
    return c.json({ success: true });
  } catch (error) {
    console.error('Error saving message:', error);
    return c.json({ error: 'Failed to save message' }, 500);
  }
});

// Admin: Get all messages
app.get('/make-server-3d698934/admin/messages', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken || !(await verifyAdmin(accessToken))) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const messages = await kv.getByPrefix('message:');
    return c.json({ messages: messages || [] });
  } catch (error) {
    console.error('Error fetching messages:', error);
    return c.json({ error: 'Failed to fetch messages' }, 500);
  }
});

// ==================== SEED DATA ROUTE ====================

// Initialize with sample products
app.post('/make-server-3d698934/seed', async (c) => {
  try {
    const sampleProducts = [
      { name: 'Fresh Apples', price: 120, image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400', category: 'Fruits', unit: 'kg' },
      { name: 'Bananas', price: 50, image: 'https://images.unsplash.com/photo-1603833665858-e61d17a86224?w=400', category: 'Fruits', unit: 'dozen' },
      { name: 'Fresh Oranges', price: 80, image: 'https://images.unsplash.com/photo-1547514701-42782101795e?w=400', category: 'Fruits', unit: 'kg' },
      { name: 'Strawberries', price: 150, image: 'https://images.unsplash.com/photo-1464965911861-746a04b4bca6?w=400', category: 'Fruits', unit: 'pack' },
      
      { name: 'Fresh Tomatoes', price: 40, image: 'https://images.unsplash.com/photo-1546470427-e26264be0b0d?w=400', category: 'Vegetables', unit: 'kg' },
      { name: 'Carrots', price: 35, image: 'https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?w=400', category: 'Vegetables', unit: 'kg' },
      { name: 'Fresh Broccoli', price: 60, image: 'https://images.unsplash.com/photo-1459411552884-841db9b3cc2a?w=400', category: 'Vegetables', unit: 'piece' },
      { name: 'Bell Peppers', price: 70, image: 'https://images.unsplash.com/photo-1563565375-f3fdfdbefa83?w=400', category: 'Vegetables', unit: 'kg' },
      
      { name: 'Fresh Milk', price: 60, image: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=400', category: 'Dairy', unit: 'liter' },
      { name: 'Cheddar Cheese', price: 200, image: 'https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d?w=400', category: 'Dairy', unit: '250g' },
      { name: 'Greek Yogurt', price: 80, image: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=400', category: 'Dairy', unit: '500g' },
      { name: 'Fresh Butter', price: 120, image: 'https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=400', category: 'Dairy', unit: '200g' },
      
      { name: 'Mixed Nuts', price: 250, image: 'https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=400', category: 'Snacks', unit: '500g' },
      { name: 'Potato Chips', price: 40, image: 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=400', category: 'Snacks', unit: 'pack' },
      { name: 'Chocolate Cookies', price: 80, image: 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=400', category: 'Snacks', unit: 'pack' },
      
      { name: 'Orange Juice', price: 90, image: 'https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=400', category: 'Beverages', unit: 'liter' },
      { name: 'Green Tea', price: 120, image: 'https://images.unsplash.com/photo-1564890369478-c89ca6d9cde9?w=400', category: 'Beverages', unit: 'pack' },
      { name: 'Coffee Beans', price: 350, image: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=400', category: 'Beverages', unit: '500g' }
    ];

    for (const product of sampleProducts) {
      const productId = generateId();
      await kv.set(`product:${productId}`, { id: productId, ...product });
    }

    return c.json({ success: true, message: 'Sample products added' });
  } catch (error) {
    console.error('Error seeding data:', error);
    return c.json({ error: 'Failed to seed data' }, 500);
  }
});

// Health check
app.get('/make-server-3d698934/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() });
});

Deno.serve(app.fetch);