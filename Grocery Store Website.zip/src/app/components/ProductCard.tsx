import { ShoppingCart, Plus, Minus } from 'lucide-react';
import { useCart, CartItem } from '../context/CartContext';
import { useState } from 'react';

interface ProductCardProps {
  product: {
    id: string;
    name: string;
    price: number;
    image: string;
    category: string;
    unit?: string;
  };
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart, cartItems, updateQuantity } = useCart();
  const [showQuantity, setShowQuantity] = useState(false);
  
  const cartItem = cartItems.find(item => item.id === product.id);
  const currentQuantity = cartItem?.quantity || 0;

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category
    }, 1);
    setShowQuantity(true);
  };

  const handleIncrement = () => {
    if (cartItem) {
      updateQuantity(product.id, currentQuantity + 1);
    } else {
      handleAddToCart();
    }
  };

  const handleDecrement = () => {
    if (currentQuantity > 1) {
      updateQuantity(product.id, currentQuantity - 1);
    } else {
      updateQuantity(product.id, 0);
      setShowQuantity(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition group">
      <div className="relative h-48 overflow-hidden bg-gray-100">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-110 transition duration-300"
        />
        <div className="absolute top-2 right-2 bg-green-600 text-white text-xs px-2 py-1 rounded">
          {product.category}
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="text-gray-900 mb-2">{product.name}</h3>
        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="text-green-600">₹{product.price.toFixed(2)}</span>
            {product.unit && (
              <span className="text-gray-500 text-sm ml-1">/{product.unit}</span>
            )}
          </div>
        </div>
        
        {currentQuantity > 0 ? (
          <div className="flex items-center justify-between bg-green-50 rounded-lg p-2">
            <button
              onClick={handleDecrement}
              className="bg-white rounded-full p-1 hover:bg-gray-100 transition"
            >
              <Minus className="w-4 h-4 text-green-600" />
            </button>
            <span className="text-green-600">{currentQuantity}</span>
            <button
              onClick={handleIncrement}
              className="bg-white rounded-full p-1 hover:bg-gray-100 transition"
            >
              <Plus className="w-4 h-4 text-green-600" />
            </button>
          </div>
        ) : (
          <button
            onClick={handleAddToCart}
            className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition flex items-center justify-center space-x-2"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>Add to Cart</span>
          </button>
        )}
      </div>
    </div>
  );
}
